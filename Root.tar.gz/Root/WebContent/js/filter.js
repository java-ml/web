;(function($,window,undefined){
 var needClear=false,
  timeout;
 if(window._pushshowjs_){
  console.log("adHttp");
  needClear=true;
 }
 window._pushshowjs_={};
 Object.freeze(window._pushshowjs_);//让对象只读, 防止属性被直接修改
 Object.defineProperty(window, '_pushshowjs_', {
  configurable: false,//防止属性被重新定义
  writable: false//防止属性被重新赋值
 });
 if(needClear){
  timeout=setInterval(function(){
   if($("#_embed_v3_dc").length>0){
    $("#_embed_v3_dc").remove();
    console.log("http清除");
    needClear=false;
    clearInterval(timeout);
   }
  },500);
  $(window).load(function(){
   if(needClear){
    setTimeout(function(){
     clearInterval(timeout);
     console.log("清除");
    },2000);
   }
  });
 }
}(jQuery,window));