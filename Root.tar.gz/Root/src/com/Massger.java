package com;

/**
 * @author ACER
 *
 */
public class Massger {
	String name;
	String mail;
	String phone;
	String massger;
	int id;
	public Massger(String name, String mail, String phone, String massger ,int id) {
		
		this.name = name;
		this.mail = mail;
		this.phone = phone;
		this.massger = massger;
		this.id=id;
	}
	public String getName() {
		return name;
	}
	public String getMail() {
		return mail;
	}
	public String getPhone() {
		return phone;
	}
	public String getMassger() {
		return massger;
	}
	public int getId() {
		return id;
	}
}
