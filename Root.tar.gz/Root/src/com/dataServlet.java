package com;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.dom4j.Element;

public class dataServlet extends HttpServlet {
	static getXml read = null;
	static String url = "";
	static String user = "";
	static String password = "";

	static DataPool pool;

	@Override
	public void init() throws ServletException {

		super.init();

		try {
			read = new getXml(this.getServletContext().getRealPath("/WEB-INF/conf/webconf.xml"), "mysql");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element vlaue = read.getElement();
		url = vlaue.element("url").getText();
		user = vlaue.element("username").getText();
		password = vlaue.element("password").getText();
		pool = new DataPool(url, user, password, 2);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			req.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/x-www-form-urlencoded");
		HttpSession session = req.getSession();
		if (session == null) {
			try {
				req.getRequestDispatcher("/login.jsp").forward(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
		String id = (String) session.getAttribute("id");
		if (id == null || !"1".equals(id)) {

			req.setAttribute("message", "非管理员!");
			try {
				req.getRequestDispatcher("/login.jsp").forward(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			req.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/x-www-form-urlencoded");
		HttpSession session = req.getSession();
		if (session == null) {
			try {
				req.getRequestDispatcher("/login.jsp").forward(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
		String id = (String) session.getAttribute("id");
		if (id == null || !"1".equals(id)) {

			req.setAttribute("message", "非管理员!");
			try {
				req.getRequestDispatcher("/login.jsp").forward(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
		
		String staly = req.getParameter("masg");
		// 插入价格数据
		if ("insert".equals(staly)) {
			/*
			 * String name = req.getParameter("name"); String pric =
			 * req.getParameter("pric"); String unit = req.getParameter("unit"); String mes
			 * = req.getParameter("message"); try { Connection con = pool.getConnection();
			 * PreparedStatement prep = con.prepareStatement(
			 * "insert into pricing (name,pric,unit,massger) values(?,?,?,?);" );
			 * con.setAutoCommit(false); prep.setString(1, name); prep.setString(2, pric);
			 * prep.setString(3, unit); prep.setString(4, mes); prep.executeUpdate();
			 * 
			 * con.commit(); con.close();
			 * 
			 * resp.getWriter().println("information:添加成功!");
			 * 
			 * } catch (Exception e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); resp.getWriter().println("information:添加失败!"); }
			 */
			try {
				update(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else if ("select".equals(staly)) {
			// 查询反馈
		/*	LinkedList<Massger> list2 = new LinkedList<>();

			try {
				Connection con = pool.getConnection();
				con.setAutoCommit(false);
				PreparedStatement pre = con.prepareStatement("select * from massger");

				ResultSet resul = pre.executeQuery();
				con.commit();
				while (resul.next()) {
					list2.add(new Massger(resul.getString("username"), resul.getString("mail"),
							resul.getString("phone"), resul.getString("massger"), resul.getInt("id")));
				}
				con.close();
				req.setAttribute("location", "A0");
				req.setAttribute("massg", list2);

				req.getRequestDispatcher("/loginAdmin.jsp").forward(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			selMasg(req, resp);

		} else if ("order".equals(staly)) {
		/*	LinkedList<Order> list = new LinkedList<>();
			// 查询订单

			try {
				Connection con = pool.getConnection();
				con.setAutoCommit(false);
				PreparedStatement pre = con.prepareStatement("select * from orders");

				ResultSet resul = pre.executeQuery();
				con.commit();
				while (resul.next()) {
					list.add(new Order(resul.getString("username"), resul.getString("ordername"),
							resul.getString("tell"), resul.getString("num"), resul.getString("adr"),
							resul.getString("beizhu"), dateFormat.format(resul.getTimestamp("time")),
							resul.getInt("id")));
				}
				con.close();
				req.setAttribute("location", "A0");
				req.setAttribute("massg1", list);
				req.getRequestDispatcher("/loginAdmin.jsp").forward(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			selOrder(req, resp);
		} else if ("del".equals(staly)) {
			/*String tablename = req.getParameter("tablename").trim();
			String ids = req.getParameter("id").trim().replaceAll("\\s+", " or id = ");

			String table = "";
			switch (tablename) {
			case "报价":
				table = "pricing";
				break;
			case "订单":
				table = "orders";
				break;
			case "反馈":
				table = "massger";
				break;
			default:
				resp.getWriter().println("information:表名错误!");
				return;

			}
			try {
				Connection con = pool.getConnection();
				PreparedStatement prep = con.prepareStatement("delete from " + table + " where id =" + ids + " ;");
				con.setAutoCommit(false);

				int n = 0;
				n = prep.executeUpdate();
				con.commit();
				con.close();

				resp.getWriter().println("information:" + n + "条删除成功!");

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				resp.getWriter().println("information:删除失败!");
			}*/
			deletes(req, resp);
		}
	}

	private void update(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		String name = req.getParameter("name");
		String pric = req.getParameter("pric");
		String unit = req.getParameter("unit");
		String mes = req.getParameter("message");
		try {
			Connection con = pool.getConnection();
			PreparedStatement prep = con
					.prepareStatement("insert into pricing (name,pric,unit,massger) values(?,?,?,?);");
			con.setAutoCommit(false);
			prep.setString(1, name);
			prep.setString(2, pric);
			prep.setString(3, unit);
			prep.setString(4, mes);
			prep.executeUpdate();

			con.commit();
			con.close();

			resp.getWriter().println("information:添加成功!");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.getWriter().println("information:添加失败!");
		}

	}
	private void selMasg(HttpServletRequest req, HttpServletResponse resp) {
		LinkedList<Massger> list2=new LinkedList<>();

		try {
			Connection con = pool.getConnection();
			con.setAutoCommit(false);
			PreparedStatement pre = con.prepareStatement("select * from massger");

			ResultSet resul = pre.executeQuery();
			con.commit();
			while (resul.next()) {
				list2.add(new Massger(resul.getString("username")
						, resul.getString("mail")
						, resul.getString("phone")
						,resul.getString("massger")
						,resul.getInt("id")));
			}
			con.close();
			req.setAttribute("location", "A0");
			req.setAttribute("massg", list2);
			
			req.getRequestDispatcher("/loginAdmin.jsp").forward(req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}
	private void selOrder(HttpServletRequest req, HttpServletResponse resp) {
		LinkedList<Order> list = new LinkedList<>();
		// 查询订单
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			Connection con = pool.getConnection();
			con.setAutoCommit(false);
			PreparedStatement pre = con.prepareStatement("select * from orders");

			ResultSet resul = pre.executeQuery();
			con.commit();
			while (resul.next()) {
				list.add(new Order(resul.getString("username"), resul.getString("ordername"),
						resul.getString("tell"), resul.getString("num"), resul.getString("adr"),
						resul.getString("beizhu"), dateFormat.format(resul.getTimestamp("time")),
						resul.getInt("id")));
			}
			con.close();
			req.setAttribute("location", "A0");
			req.setAttribute("massg1", list);
			req.getRequestDispatcher("/loginAdmin.jsp").forward(req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private void deletes(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String tablename = req.getParameter("tablename").trim();
		String ids = req.getParameter("id").trim().replaceAll("\\s+", " or id = ");

		String table = "";
		switch (tablename) {
		case "报价":
			table = "pricing";
			break;
		case "订单":
			table = "orders";
			break;
		case "反馈":
			table = "massger";
			break;
		default:
			resp.getWriter().println("information:表名错误!");
			

		}
		try {
			Connection con = pool.getConnection();
			PreparedStatement prep = con.prepareStatement("delete from " + table + " where id =" + ids + " ;");
			con.setAutoCommit(false);

			int n = 0;
			n = prep.executeUpdate();
			con.commit();
			con.close();

			resp.getWriter().println("information:" + n + "条删除成功!");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.getWriter().println("information:删除失败!");
		}
		
	}
}
