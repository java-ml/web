package com;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.dom4j.Element;

/**
 * Servlet implementation class loginServlet
 */

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	volatile static getXml read = null;
	SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	private static final long serialVersionUID = 1L;

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		HttpSession session = request.getSession(false);
		if (session != null) {
			String usrname = (String) session.getAttribute("username");

			if (usrname == null) {
				response.getWriter().append("请登录!!!");
				response.setHeader("refresh", "2;url=index.jsp");
			}
		}
		if (session == null || request.getParameter("logout") == null) {
			response.getWriter().append("请登录!!!");
			response.setHeader("refresh", "2;url=index.jsp");
		} else if (request.getParameter("logout").equals("out")) {
			session.invalidate();
			response.sendRedirect("index.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		HttpSession session = request.getSession(false);
		String usrname = request.getParameter("username");
		String password = request.getParameter("password");
		if (session == null || usrname == "" || password == "") {
			request.setAttribute("message", "账号或密码不能为空!");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		} else {
			try {

				read = new getXml(this.getServletContext().getRealPath("/WEB-INF/conf/webconf.xml"), "adminuser");

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			List<Element> vlaue2 = read.getElement().elements();
			for (Element vlu : vlaue2) {
				if (vlu != null && vlu.element("name").getText().equals(usrname)
						&& vlu.element("password").getText().equals(password)
						&& vlu.element("id").getData().equals("1")) {

					session.setAttribute("username", usrname);
					session.setAttribute("id", vlu.element("id").getData());
					request.getRequestDispatcher("/loginAdmin.jsp").forward(request, response);
					FileWriter outputStream = new FileWriter(
							new File(this.getServletContext().getRealPath("/WEB-INF/log")), true);
					outputStream.append(usrname + "\ntime:" + sf.format(new Date()) + "\n-------------------------\n");
					outputStream.close();
					return;
				}
			}
			request.setAttribute("message", "账号或密码错误!");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}

	}

}
