package com;

public class Order {
	String name ;
	String ordername ;
	String tell;
	String num;
	String adr ;
	String beizhu ;
	String time;
	int id;
	public Order(String name, String ordername, String tell, String num, String adr, String beizhu,String time,int id) {
		
		this.name = name;
		this.ordername = ordername;
		this.tell = tell;
		this.num = num;
		this.adr = adr;
		this.beizhu = beizhu;
		this.time=time;
		this.id=id;
	}
	public String getName() {
		return name;
	}
	public String getOrdername() {
		return ordername;
	}
	public String getTell() {
		return tell;
	}
	public String getNum() {
		return num;
	}
	public String getAdr() {
		return adr;
	}
	public String getBeizhu() {
		return beizhu;
	}
	public String getTime() {
		return time;
	}
	public int getId() {
		return id;
	}
}
