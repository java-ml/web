package com;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.LinkedList;
import java.util.logging.Logger;

import javax.sql.DataSource;
 /*
  * 数据池化   JDBC-MySQL
  * 
*/
public class DataPool implements DataSource {

	private LinkedList<Connection> list = new LinkedList<>();
	private String url,name,password;
	private int  n;
	public DataPool(String url, String name, String password, int n) {
		this.url=url+"?useUnicode=true&amp;characterEncoding=UTF-8";
		this.name=name;
		this.password=password;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			for (int i = 0; i <= n; i++) {
				list.add(new Myconf(DriverManager.getConnection(url, name, password),this));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public PrintWriter getLogWriter() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setLogWriter(PrintWriter out) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public void setLoginTimeout(int seconds) throws SQLException {
		// TODO Auto-generated method stub

	}

	@Override
	public int getLoginTimeout() throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Logger getParentLogger() throws SQLFeatureNotSupportedException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> T unwrap(Class<T> iface) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isWrapperFor(Class<?> iface) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	public synchronized void addConn(Connection con) {
		list.addFirst(con);
	}
	public synchronized int listNum() {
		return list.size();
	}
	public int poolsize() {
		return n;
	}
	@Override
	public synchronized Connection getConnection() throws SQLException {
		if(list.size()==0)return   DriverManager.getConnection(url, name,password);
		else{ 
			Connection connection= list.getFirst();
			list.removeFirst();
			return connection;
		}
	}

	@Override
	public synchronized Connection getConnection(String username, String password) throws SQLException {
		if(list.size()==0)return   DriverManager.getConnection(url, username,password);
		else{ 
			Connection connection= list.getFirst();
			list.removeFirst();
			return connection;
		}
	}

}
