package com;

public class Pricing{
	public int id;
	public String name;
	public float pri;
	public String unit;
	public String massger;
	public Pricing() {
		// TODO Auto-generated constructor stub
	}
	public Pricing(String name, float pri, String unit, String massger,int id) {
		this.name = name;
		this.pri = pri;
		this.unit = unit;
		this.massger = massger;
		this.id=id;
	}
	
}
