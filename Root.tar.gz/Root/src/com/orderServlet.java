package com;
import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dom4j.Element;

public class orderServlet extends HttpServlet {
	/**
	 * 前端订单
	 */
	private static final long serialVersionUID = 1L;
	volatile getXml read=null;
	volatile String url="";
	volatile String user="";
	volatile String password="";
	volatile int n; 
	volatile DataPool pool;
	@Override
	public void init() throws ServletException {
		
		super.init();
		
		
		try {
			read=new getXml(this.getServletContext().getRealPath("/WEB-INF/conf/webconf.xml")
					, "mysql");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 Element vlaue=read.getElement();
		 url=vlaue.element("url").getText();
		 user=vlaue.element("username").getText();
		 password=vlaue.element("password").getText();
		 n=Integer.valueOf(vlaue.element("poolsize").getText());
		 pool=new DataPool(url, user, password, n);
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		super.doGet(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=UTF-8");
		// 获得数据
		String name = req.getParameter("name");
		String ordername = req.getParameter("ordername");
		String tell = req.getParameter("tell");
		String num = req.getParameter("number");
		String adr = req.getParameter("adress");
		String beizhu = req.getParameter("beizhu");
		try {
			Connection conn=pool.getConnection();
			PreparedStatement prep=conn.prepareStatement(
					"insert into orders (username,ordername,tell,num,adr,beizhu,time) values(?,?,?,?,?,?,now());");
			conn.setAutoCommit(false);
			prep.setString(1, name);
			prep.setString(2, ordername);
			prep.setString(3, tell);
			prep.setString(4, num);
			prep.setString(5, adr);
			prep.setString(6, beizhu);
			prep.executeUpdate();
			conn.commit();
			conn.close();
			req.setAttribute("sub", "提交成功");
		} catch (Exception e) {
			req.setAttribute("sub", "提交失败");
			e.printStackTrace();
		}
		finally {
			req.getRequestDispatcher("/oder.jsp").forward(req, resp);
		}
		
		
	}
}
