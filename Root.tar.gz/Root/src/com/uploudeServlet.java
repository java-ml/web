package com;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 处理图片，视频
 */

public class uploudeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static getXml read=null;
	

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public uploudeServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		try {
			req.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/x-www-form-urlencoded");
		HttpSession session = req.getSession();
		if(session==null){
			try {
				req.getRequestDispatcher("/login.jsp").forward(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
		String id = (String) session.getAttribute("id");
		if (id == null || !"1".equals(id)) {
			
			req.setAttribute("message", "非管理员!");
			try {
				req.getRequestDispatcher("/login.jsp").forward(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}

	}

	/**
	 * @throws UnsupportedEncodingException 
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException {
		
		byte[] by = new byte[1024 * 1024];
		try {
			req.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/x-www-form-urlencoded");
		HttpSession session = req.getSession();
		if(session==null){
			try {
				req.getRequestDispatcher("/login.jsp").forward(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
		String id = (String) session.getAttribute("id");
		if (id == null || !"1".equals(id)) {
			
			req.setAttribute("message", "非管理员!");
			try {
				req.getRequestDispatcher("/login.jsp").forward(req, resp);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
		String del = (String) req.getParameter("masg");

		if (del != null && del.equals("del")) {
			String path ="/";
			if ("photo".equals((String) req.getParameter("format"))) {
				path = req.getServletContext().getRealPath("/img");
			}else if ("video".equals((String) req.getParameter("format"))) {
				path=req.getServletContext().getRealPath("/video");
			}
			
			
			String[] file = req.getParameter("photoname").trim().split("\\s+");
			File fil;
			StringBuffer buf = new StringBuffer("删除失败!");
			boolean issu = true;
			for (int i = 0; i < file.length; i++) {
				String url =URLEncoder.encode(file[i].trim(),"utf-8").replaceAll("%", "-");
				fil = new File(path + "/" + url);
				
				if (!fil.exists() ) {
					issu = false;
					buf.append(file[i]);
					buf.append(";");
				}else if (!fil.delete()) {
					issu = false;
					buf.append(file[i]);
					buf.append(";");
				}

			}
			if (issu) {
				try {
					resp.getWriter().println("information:删除成功!");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} else {
				try {
					resp.getWriter().println("information:" + buf.toString());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				;
			}
			return;
		} else {
			ServletInputStream inputStream = null;
			DataOutputStream out = null;
			try {
					
				inputStream = req.getInputStream();
				String name = "";

				String tmp = "";
				int len = 0;
				int index = 0;
				inputStream.readLine(by, 0, 256);
				
				tmp = new String(by);
				String local="";
				while ((len = inputStream.readLine(by, 0, 1024)) != -1) {
					tmp = new String(by, 0, len);
					
					if (tmp.indexOf("Content-Type") != -1) {
						break;
					} else if ((index = tmp.indexOf("filename=\"")) != -1) {
						name = tmp.substring(index + 10, tmp.length() - 3);
					}else if (tmp.indexOf("video")!=-1) {
						local="/video";
					}else if (tmp.indexOf("image")!=-1) {
						local="/img";
					}

				}
				String path = req.getServletContext().getRealPath(local);// 这里保存图片路径
			
				
				File uploadFile = new File(path);// 路径文件，一定要有文件夹，没有则创建，mkdir
				if (!uploadFile.exists())
					uploadFile.mkdirs();

				File upload = new File(path + "/" + URLEncoder.encode(name, "utf-8").replaceAll("[-\\s+]", "_").replaceAll("%", "-"));

				
				inputStream.readLine(by, 0, 512);
				
				out = new DataOutputStream(new FileOutputStream(upload));
				while ((len = inputStream.read(by, 0, 4096)) != -1) {

					out.write(by, 0, len);

				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					out.close();
					inputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			// 关闭io，代码从简
		}
	}

}
