package com;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.dom4j.Element;
//处理前端反馈
public class massgerServlet extends HttpServlet {
	volatile static getXml read=null;
	volatile static String url="";
	volatile static String user="";
	volatile static String password="";
	volatile static int n; 
	volatile static DataPool pool;
	@Override
	public void init() throws ServletException {
		
		super.init();
		
		
		try {
			read=new getXml(this.getServletContext()
					.getRealPath("/WEB-INF/conf/webconf.xml")
					, "mysql");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 Element vlaue=read.getElement();
		 url=vlaue.element("url").getText();
		 user=vlaue.element("username").getText();
		 password=vlaue.element("password").getText();
		 n=Integer.valueOf(vlaue.element("poolsize").getText());
		 pool=new DataPool(url, user, password, n);
	}
			@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
				try {
					req.setCharacterEncoding("utf-8");
				} catch (UnsupportedEncodingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				resp.setCharacterEncoding("UTF-8");
				resp.setContentType("application/x-www-form-urlencoded");
	
					try {
						req.getRequestDispatcher("/index.jsp").forward(req, resp);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return;
				}	
	

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=UTF-8");
		// 获得数据
		String name = req.getParameter("username");
		String mail = req.getParameter("email");
		String phone = req.getParameter("phone");
		String mes = req.getParameter("message");
		try {
			Connection conn = pool.getConnection();
			PreparedStatement prep = conn.prepareStatement(
					"insert into massger (username,mail,phone,massger,time) values(?,?,?,?,now());");
			conn.setAutoCommit(false);
			prep.setString(1, name);
			prep.setString(2, mail);
			prep.setString(3, phone);
			prep.setString(4, mes);
			prep.executeUpdate();
			conn.commit();
			conn.close();
			req.setAttribute("sub", "反馈成功");
		} catch (Exception e) {
			req.setAttribute("sub", "反馈失败");
			e.printStackTrace();
		}
		finally {
			req.getRequestDispatcher("/contact.jsp").forward(req, resp);
		}
		

	}
}
