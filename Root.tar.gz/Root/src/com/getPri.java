package com;

import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.dom4j.Element;

public class getPri extends HttpServlet {
	/**
	 * 得到报价
	 */
	private static final long serialVersionUID = 1L;
	volatile getXml read = null;
	volatile static String url = "";
	volatile static String user = "";
	volatile static String password = "";
	volatile static int n;
	volatile static DataPool pool;

	@Override
	public void init() throws ServletException {

		super.init();

		try {
			read = new getXml(this.getServletContext().getRealPath("/WEB-INF/conf/webconf.xml"), "mysql");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Element vlaue = read.getElement();
		url = vlaue.element("url").getText();
		user = vlaue.element("username").getText();
		password = vlaue.element("password").getText();
		n = Integer.valueOf(vlaue.element("poolsize").getText());
		pool = new DataPool(url, user, password, n);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		ArrayList<Pricing> list = new ArrayList<>(10);

		try {
			Connection con = pool.getConnection();
			con.setAutoCommit(false);
			PreparedStatement pre = con.prepareStatement("select * from pricing");

			ResultSet resul = pre.executeQuery();
			con.commit();
			while (resul.next()) {
				list.add(new Pricing(resul.getString("name"), resul.getFloat("pric"), resul.getString("unit"),
						resul.getString("massger"),resul.getInt("id")));
			}
			con.close();

			req.setAttribute("pric", list);
			req.getRequestDispatcher("/pricing.jsp").forward(req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
