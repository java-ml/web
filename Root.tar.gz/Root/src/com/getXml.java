package com;
import java.io.File;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
/*
 * 
 * 读取webconf文件夹下配置文件
 * 
 * */
public class getXml {
	private   Element element;
	public getXml(String file,String key) {
		 element=getBudile(file, key);
	}

	private  Element getRootElemen(String filename) {
		 try {  
		        SAXReader saxReader = new SAXReader();  
		        return saxReader.read(new File(filename)).getRootElement(); // 读取XML文件,获得document对象  
		    } catch (Exception ex) {  
		        ex.printStackTrace();  
		    }  
		     
		return null;
		
	}
	private  Element getBudile(String filename,String key) {
		return getRootElemen(filename).element(key);
	}
	public  Element getElement() {
		return element;
	}
}
